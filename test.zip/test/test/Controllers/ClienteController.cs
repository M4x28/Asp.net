﻿using System.Web.Mvc;

namespace test.Controllers
{
    public class ClienteController : Controller
    {
        
    }
}