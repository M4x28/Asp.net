﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using test.Models;
using System.Data.Entity;
using test.ViewsModels;

namespace test.Controllers
{
    public class CustomerController : Controller
    {
        private ApplicationDbContext _context;

        public CustomerController()
        {
            _context = new ApplicationDbContext();
        }

        protected override void Dispose(bool disposing)
        {
            _context.Dispose();
        }

        public ActionResult New()
        {
            var membershipType = _context.Types.ToList();
            var viewModel = new NewCustomerViewModel
            {
                Membership = membershipType
            };
            return View("New", viewModel);
        }

        //mvcaction4
        //Only Post request
        [HttpPost]
        public ActionResult Save(Customer customer)
        {
            if (customer.Id == 0)
                _context.Customers.Add(customer);
            else
            {
                var customerInDb = _context.Customers.Single(c => c.Id == customer.Id);

                customerInDb.Nome = customer.Nome;
                customerInDb.Compleanno = customer.Compleanno;
                customerInDb.MembershipTypeId = customer.MembershipTypeId;
                customerInDb.IsSubscribedToNewsLetter = customer.IsSubscribedToNewsLetter;
            }
            _context.Customers.Add(customer);
            _context.SaveChanges();
            return RedirectToAction("Index", "Customer");
        }

        // GET: Customer
        public ActionResult Index()
        {
            var customers = _context.Customers.Include(c => c.MembershipType).ToList();
            return View(customers);
        }

        public ActionResult Dettagli(int id)
        {
            var cliente = _context.Customers.Include(c => c.MembershipType).SingleOrDefault(c => c.Id == id); //PER CREARE UN METODO ANONIMO, LA FRECCIA INDICA 'VA A'
            if (cliente == null)
                return HttpNotFound();

            return View(cliente);
        }

        public ActionResult Edit(int id)
        {
            var customers = _context.Customers.SingleOrDefault(c => c.Id == id);

            if (customers == null)
            {
                return HttpNotFound();
            }

            var viewModel = new NewCustomerViewModel
            {
                Customer = customers,
                Membership = _context.Types.ToList()
            };

            return View("New", viewModel);
        }
    }
}