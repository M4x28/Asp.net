﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Models
{
    public class Film
    {
        public int Id { get; set; }
        [Required]
        [StringLength(255)]
        public String Nome { get; set; }
        public String Genere { get; set; }
        public String DataRilascio { get; set; }
        public String DataAggiunta { get; set; }
        public int Stock { get; set; }
    }
}