﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Models
{
    public class Cliente
    {
        public int Id { get; set; }
        [Required]
        [StringLength(255)]
        public String Nome { get; set; }
        public String Compleanno { get; set; }
        public bool  IsSubscribedToNewsLetter{ get; set; }
        public MembershipType MembershipType { get; set; }
        public byte MembershipTypeId { get; set; }
    }
}