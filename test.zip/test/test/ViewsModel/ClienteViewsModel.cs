﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using $safeprojectname$.Models;

namespace $safeprojectname$.ViewsModel
{
    public class ClienteViewsModel /*: System.Collections.IEnumerable */
    {
        public int Id { get; set; }
        public List<Cliente> Clienti { get; set; }


        /*    public System.Collections.IEnumerator GetEnumerator()
            {
                throw new NotImplementedException();
            }
        }

        */

    }
}
