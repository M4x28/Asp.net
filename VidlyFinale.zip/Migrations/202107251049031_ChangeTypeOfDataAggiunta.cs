namespace $safeprojectname$.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ChangeTypeOfDataAggiunta : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Films", "DataAggiunta", c => c.String());
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Films", "DataAggiunta", c => c.String(nullable: false));
        }
    }
}
