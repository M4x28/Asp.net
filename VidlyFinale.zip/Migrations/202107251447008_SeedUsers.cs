namespace $safeprojectname$.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class SeedUsers : DbMigration
    {
        public override void Up()
        {
            Sql(@"
INSERT INTO [dbo].[AspNetUsers] ([Id], [Email], [EmailConfirmed], [PasswordHash], [SecurityStamp], [PhoneNumber], [PhoneNumberConfirmed], [TwoFactorEnabled], [LockoutEndDateUtc], [LockoutEnabled], [AccessFailedCount], [UserName]) VALUES (N'25eaf2d2-0bd5-418c-bcbc-88ab7e5c6e98', N'admin@vidly.com', 0, N'ANGW5641UCJq/jjmGGYL3H8AvaX6osXuByNe3b7oiis+wqts65F7ksZKfP3bkgYkaw==', N'9a9ad060-1dbd-4b3c-a11a-36c32200112f', NULL, 0, 0, NULL, 1, 0, N'admin@vidly.com')
INSERT INTO [dbo].[AspNetUsers] ([Id], [Email], [EmailConfirmed], [PasswordHash], [SecurityStamp], [PhoneNumber], [PhoneNumberConfirmed], [TwoFactorEnabled], [LockoutEndDateUtc], [LockoutEnabled], [AccessFailedCount], [UserName]) VALUES (N'44701e96-8fd0-4a5d-8452-19b695aae427', N'guest@vidly.com', 0, N'ABDVftgYhkvdWnN/tn4iKDkOIpLWv+Yc0mhJ7I7zV9A8TArtDzUNEvpGCESXIW37zA==', N'eb2eba9f-e871-4b8f-989f-6d0cfb6bc57c', NULL, 0, 0, NULL, 1, 0, N'guest@vidly.com')

INSERT INTO [dbo].[AspNetRoles] ([Id], [Name]) VALUES (N'e6853146-fde2-4680-a8c7-2d1b866bf289', N'CanManageMovies')

INSERT INTO [dbo].[AspNetUserRoles] ([UserId], [RoleId]) VALUES (N'25eaf2d2-0bd5-418c-bcbc-88ab7e5c6e98', N'e6853146-fde2-4680-a8c7-2d1b866bf289')
");
        }
        
        public override void Down()
        {
        }
    }
}
