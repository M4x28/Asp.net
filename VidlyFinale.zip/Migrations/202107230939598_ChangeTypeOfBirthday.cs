namespace $safeprojectname$.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ChangeTypeOfBirthday : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Clientes", "Compleanno", c => c.DateTime());
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Clientes", "Compleanno", c => c.String());
        }
    }
}
