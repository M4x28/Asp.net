namespace $safeprojectname$.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddNumerAvailableInFilm : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Films", "NumberAvailable", c => c.Byte(nullable: false));

            Sql("UPDATE Films SET NumberAvailable = Stock");
        }
        
        public override void Down()
        {
            DropColumn("dbo.Films", "NumberAvailable");
        }
    }
}
