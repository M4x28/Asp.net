namespace $safeprojectname$.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddClienteInRental : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Rentals", "Cliente_Id", c => c.Int(nullable: false));
            CreateIndex("dbo.Rentals", "Cliente_Id");
            AddForeignKey("dbo.Rentals", "Cliente_Id", "dbo.Clientes", "Id", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Rentals", "Cliente_Id", "dbo.Clientes");
            DropIndex("dbo.Rentals", new[] { "Cliente_Id" });
            DropColumn("dbo.Rentals", "Cliente_Id");
        }
    }
}
