﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using $safeprojectname$.Models;

namespace $safeprojectname$.DTOs
{
    public class ClienteDto
    {
        public int Id { get; set; }

        [Required]
        [StringLength(255)]
        public String Nome { get; set; }

        //[Min18YearsIfAMember]
        public DateTime? Compleanno { get; set; }

        public bool IsSubscribedToNewsLetter { get; set; }

        public MembershipTypeDto MembershipType { get; set; }
        
        public byte MembershipTypeId { get; set; }
    }
}