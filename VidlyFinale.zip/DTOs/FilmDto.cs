﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace $safeprojectname$.DTOs
{
    public class FilmDto
    {
        public int Id { get; set; }

        [Required]
        [StringLength(255)]
        public String Nome { get; set; }

        public byte GenereId { get; set; }

        public String DataRilascio { get; set; }

        [Required]
        public String DataAggiunta { get; set; }

        [Range(1, 20)]
        public int Stock { get; set; }
    }
}