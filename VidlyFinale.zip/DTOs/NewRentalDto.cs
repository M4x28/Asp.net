﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$.DTOs
{
    public class NewRentalDto
    {
        public int ClienteId { get; set; }
        public List<int> FilmIds { get; set; }
    }
}