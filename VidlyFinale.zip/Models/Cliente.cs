﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Models
{
    public class Cliente
    {
        public int Id { get; set; }

        [Required]
        [StringLength(255)]
        public String Nome { get; set; }

        [Display(Name = "Data di Nascita")]
        [Min18YearsIfAMember]
        public DateTime? Compleanno { get; set; }

        public bool IsSubscribedToNewsLetter { get; set; }

        public MembershipType MembershipType { get; set; }

        [Display(Name = "Tipo di abbonamento")]
        [Required(ErrorMessage = "Specificare il tipo di abbonamento.")]
        public byte MembershipTypeId { get; set; }
    }
}