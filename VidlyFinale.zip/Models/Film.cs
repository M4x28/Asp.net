﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using $safeprojectname$.Models;

namespace $safeprojectname$.Models
{
    public class Film
    {
        public int Id { get; set; }

        [Required]
        [StringLength(255)]
        public String Nome { get; set; }

        public Genere Genere { get; set; }

        [Display(Name = "Genere")]
        [Required(ErrorMessage = "Il genere è obbligatorio.")]
        public byte GenereId { get; set; }

        [Display(Name = "Data di uscita")]
        [Required(ErrorMessage = "La data di uscita è obbligatoria.")]
        public String DataRilascio { get; set; }

        public String DataAggiunta { get; set; }

        [Range(1, 20)]
        public int Stock { get; set; }

        public byte NumberAvailable { get; set; }
    }
}