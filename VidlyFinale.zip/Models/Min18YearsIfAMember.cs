﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Models
{
    public class Min18YearsIfAMember : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var cliente = (Cliente)validationContext.ObjectInstance;

            if (cliente.MembershipTypeId == MembershipType.Unknown ||
                cliente.MembershipTypeId == MembershipType.PayAsYouGo)
                return ValidationResult.Success;

            if (cliente.Compleanno == null)
                return new ValidationResult("Il compleanno è obbligatorio.");

            var età = DateTime.Today.Year - cliente.Compleanno.Value.Year;

            return (età >= 18) 
                ? ValidationResult.Success 
                : new ValidationResult("Il cliente deve avere almeno 18 anni per abbonarsi");
        }
    }
}