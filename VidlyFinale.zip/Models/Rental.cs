﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Models
{
    public class Rental
    {
        public int Id { get; set; }

        [Required]
        public Cliente Cliente { get; set; }

        [Required]
        public Film Film { get; set; }

        public DateTime DateRented { get; set; }

        public DateTime? DateReturned { get; set; }
    }
}