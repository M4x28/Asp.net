﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Models
{
    public static class RoleName
    {
        public const String CanManageMovies = "CanManageMovies";
    }
}