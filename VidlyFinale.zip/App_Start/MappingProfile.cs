﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AutoMapper;
using $safeprojectname$.DTOs;
using $safeprojectname$.Models;

namespace $safeprojectname$.App_Start
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            //Domain to DTO
            Mapper.CreateMap<Cliente, ClienteDto>();
            Mapper.CreateMap<Film, FilmDto>();
            Mapper.CreateMap<Genere, GenereDto>();
            Mapper.CreateMap<MembershipType, MembershipTypeDto>();

           //DTOs to Domanin
            Mapper.CreateMap<ClienteDto, Cliente>()
                .ForMember(c => c.Id, opt => opt.Ignore());

            Mapper.CreateMap<FilmDto, Film>()
                .ForMember(c => c.Id, opt => opt.Ignore());
        }
    }
}