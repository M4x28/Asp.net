﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using $safeprojectname$.Models;
using $safeprojectname$.ViewsModel;
using AutoMapper;
using System.Data.Entity.Validation;

namespace $safeprojectname$.Controllers
{
    public class FilmController : Controller
    {
        
        private ApplicationDbContext _context;
        public FilmController()
        {
            _context = new ApplicationDbContext(); //DISPOSABLE OBJECT
        }

        protected override void Dispose(bool disposing)
        {
            _context.Dispose();
        }


        [Authorize(Roles = RoleName.CanManageMovies)]
        public ActionResult New()
        {
            var generi = _context.Generi.ToList();
            var viewModel = new FilmFormViewModel
            {           
                Generi = generi
            };

            return View("FilmForm", viewModel);
        }

        [HttpPost] //PER CREARE UNA RISORSA
        [ValidateAntiForgeryToken]
        public ActionResult Save(Film film)
        {

            if (film.Id == 0)
                _context.Films.Add(film);
            else
            {
                var filmInDb = _context.Films.Single(f => f.Id == film.Id);
                _context.Entry(filmInDb).CurrentValues.SetValues(film);

                //TryUpdateModel(clienteInDb);

                Mapper.Map(film, filmInDb);
                
            }

              _context.SaveChanges();

            return RedirectToAction("Index", "Film");
        }

        // GET: Film
        public ActionResult Index()
        {
            if (User.IsInRole(RoleName.CanManageMovies))
                return View("Index");

            //MemoryCache.Default["Magic String"] as IRnumerable<Type>; SALVARE DATI SULLA CACHE
            return View("ReadOnlyIndex");
        }

        public ActionResult Dettagli(int id)
        {
            var film = _context.Films.Include(f => f.Genere).SingleOrDefault(f => f.Id == id);
            if (film == null)
                return HttpNotFound();

            return View(film);
        }

        //GET: Film/Edit/id
        public ActionResult Edit(int id)
        {
            var film = _context.Films.SingleOrDefault(f => f.Id == id);
            if (film == null)
                return HttpNotFound();

            var viewModel = new FilmFormViewModel
            {
                Film = film,
                Generi = _context.Generi.ToList()
            };

            return View("FilmForm", viewModel);
        }
    }
}