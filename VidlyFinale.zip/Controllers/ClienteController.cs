﻿using System;
using System.Runtime;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using $safeprojectname$.Models;
using $safeprojectname$.ViewsModel;

namespace $safeprojectname$.Controllers
{
    public class ClienteController : Controller
    {
        private ApplicationDbContext _context;
        public ClienteController()
        {
            _context = new ApplicationDbContext(); //DISPOSABLE OBJECT
        }

        protected override void Dispose(bool disposing)
        {
            _context.Dispose();
        }

        [Authorize(Roles = RoleName.CanManageMovies)]
        public ActionResult New()
        {
            var membershipTypes = _context.MembershipTypes.ToList();
            var viewModel = new ClienteFormViewModel
            {
                Cliente = new Cliente(),
                MembershipTypes = membershipTypes

            };
            return View("ClienteForm", viewModel);
        }

        [HttpPost] //PER CREARE UNA RISORSA
        [ValidateAntiForgeryToken]
        public ActionResult Save(Cliente cliente)
        {
            if (!ModelState.IsValid)
            {
                var viewModel = new ClienteFormViewModel
            {
                Cliente = cliente,
                MembershipTypes = _context.MembershipTypes.ToList()

            };
                return View("ClienteForm", viewModel);
            }

            if (cliente.Id == 0)
                _context.Clienti.Add(cliente);
            else
            {
                var clienteInDb = _context.Clienti.Single(c => c.Id == cliente.Id);
                //TryUpdateModel(clienteInDb);

                clienteInDb.Nome = cliente.Nome;
                clienteInDb.Compleanno = cliente.Compleanno;
                clienteInDb.MembershipTypeId = cliente.MembershipTypeId;
                clienteInDb.IsSubscribedToNewsLetter = cliente.IsSubscribedToNewsLetter;
            }

            _context.SaveChanges();

            return RedirectToAction("Index", "Cliente");
        }

        // GET: Cliente
        public ActionResult Index()
        {
            if (User.IsInRole(RoleName.CanManageMovies))
                return View("Index");

            //MemoryCache.Default["Magic String"] as IRnumerable<Type>; SALVARE DATI SULLA CACHE
                return View("ReadOnlyIndex");
        }

        public ActionResult Dettagli(int id)
        {
            var cliente = _context.Clienti.Include(c => c.MembershipType).SingleOrDefault(c => c.Id == id); //PER CREARE UN METODO ANONIMO, LA FRECCIA INDICA 'VA A'
            if (cliente == null)
                return HttpNotFound();

            return View(cliente);
        }

        public ActionResult Edit(int id)
        {
            var cliente = _context.Clienti.SingleOrDefault(c => c.Id == id);
            if (cliente == null)
                return HttpNotFound();

            var viewModel = new ClienteFormViewModel
            {
                Cliente = cliente,
                MembershipTypes = _context.MembershipTypes.ToList()
            };

            return View("ClienteForm", viewModel);
        }
    }
}