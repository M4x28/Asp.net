﻿using System;
using System.Data.Entity;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using $safeprojectname$.DTOs;
using $safeprojectname$.Models;
using AutoMapper;

namespace $safeprojectname$.Controllers.API
{
    public class FIlmsController : ApiController
    {
        private ApplicationDbContext _context;

        public FIlmsController()
        {
            _context = new ApplicationDbContext();
        }

        //GET: /api/films
        public IHttpActionResult GetFilms()
        {
            var filmsDtos = _context.Films
                .Include(f => f.Genere)
                .ToList()
                .Select(Mapper.Map<Film, FilmDto>);
            return Ok(filmsDtos);
        }

        //GET: /api/films/id
        public IHttpActionResult GetFilm(int id)
        {
            var film = _context.Films.SingleOrDefault(f => f.Id == id);
            if (film == null)
                return NotFound();
                

            return Ok(Mapper.Map<Film, FilmDto>(film));
        }

        //POST: /api/films
        [HttpPost]
        public IHttpActionResult CreateFilm(FilmDto filmDto)
        {
            if (!ModelState.IsValid)
                return BadRequest();

            var film = Mapper.Map<FilmDto, Film>(filmDto);
            _context.Films.Add(film);
            _context.SaveChanges();

            filmDto.Id = film.Id;

            return Created(new Uri(Request.RequestUri + "/" + film.Id), filmDto);
        }

        //PUT: /api/films/id
        [HttpPut]
        public IHttpActionResult UpdateFilm(int id, FilmDto filmDto)
        {
            if (!ModelState.IsValid)
                return BadRequest();

            var filmInDb = _context.Films.SingleOrDefault(f => f.Id == id);

            if (filmInDb == null)
                return NotFound();

                Mapper.Map(filmDto, filmInDb);

                return Ok(_context.SaveChanges());
            

        }

        //DELETE: /api/films/id
        [HttpDelete]
        public IHttpActionResult DeleteFilm(int id)
        {
            var filmInDb = _context.Films.SingleOrDefault(f => f.Id == id);

            if (filmInDb == null)
                return NotFound();

            _context.Films.Remove(filmInDb);
            return Ok(_context.SaveChanges());
        }
    }
}
