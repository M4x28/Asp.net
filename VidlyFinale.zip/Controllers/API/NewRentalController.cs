﻿using System;
using System.Data.Entity;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using $safeprojectname$.DTOs;
using $safeprojectname$.Models;
using AutoMapper;

namespace $safeprojectname$.Controllers.API
{
    public class NewRentalController : ApiController
    {
        private ApplicationDbContext _context;

        public NewRentalController()
        {
            _context = new ApplicationDbContext();
        }

        [HttpPost]
        public IHttpActionResult CreateNewRental(NewRentalDto newRental)
        {
            var cliente = _context.Clienti.Single(c => c.Id == newRental.ClienteId);
            var films = _context.Films.Where(f => newRental.FilmIds.Contains(f.Id)).ToList();

            foreach (var film in films)
            {
                if (film.NumberAvailable == 0)
                    return BadRequest("Il film non è disponibile.");

                film.NumberAvailable--;

                var rental = new Rental
                {
                    Cliente = cliente,
                    Film = film,
                    DateRented = DateTime.Now
                };

                _context.Rentals.Add(rental);
            }

            return Ok();
        }

    }
}
