﻿using System;
using System.Data.Entity;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using $safeprojectname$.DTOs;
using $safeprojectname$.Models;
using AutoMapper;

namespace $safeprojectname$.Controllers.API
{
    public class ClientiController : ApiController
    {
        private ApplicationDbContext _context;

        public ClientiController()
        {
            _context = new ApplicationDbContext();
        }

        //GET: /api/clienti
        public IHttpActionResult GetClienti()
        {
            var clientiDtos = _context.Clienti
                .Include(c => c.MembershipType)
                .ToList()
                .Select(Mapper.Map<Cliente, ClienteDto>);
            return Ok(clientiDtos);
        }

        //GET: /api/clienti/id
        public IHttpActionResult GetCliente(int id)
        {
            var cliente = _context.Clienti.SingleOrDefault(c => c.Id == id);
            if (cliente == null)
                return NotFound();
                

            return Ok(Mapper.Map<Cliente, ClienteDto>(cliente));
        }

        //POST: /api/clienti
        [HttpPost]
        public IHttpActionResult CreateCliente(ClienteDto clienteDto)
        {
            if (!ModelState.IsValid)
                return BadRequest();

            var cliente = Mapper.Map<ClienteDto, Cliente>(clienteDto);
            _context.Clienti.Add(cliente);
            _context.SaveChanges();

            clienteDto.Id = cliente.Id;

            return Created(new Uri(Request.RequestUri + "/" + cliente.Id), clienteDto);
        }

        //PUT: /api/clienti/id
        [HttpPut]
        public void UpdateCliente(int id, ClienteDto clienteDto)
        {
            if (!ModelState.IsValid)
            {
                var notFoundMessage = new HttpResponseMessage(HttpStatusCode.BadRequest);
                throw new HttpResponseException(notFoundMessage);
            }

            var clienteInDb = _context.Clienti.SingleOrDefault(c => c.Id == id);

            if (clienteInDb == null)
            {
                var notFoundMessage = new HttpResponseMessage(HttpStatusCode.NotFound);
                throw new HttpResponseException(notFoundMessage);
            }

                Mapper.Map(clienteDto, clienteInDb);

                _context.SaveChanges();
            

        }

        //DELETE: /api/clienti/id
        [HttpDelete]
        public void DeleteCliente(int id)
        {
            var clienteInDb = _context.Clienti.SingleOrDefault(c => c.Id == id);
            
            if (clienteInDb == null)
            {
                var notFoundMessage = new HttpResponseMessage(HttpStatusCode.NotFound);
                throw new HttpResponseException(notFoundMessage);
            }

            _context.Clienti.Remove(clienteInDb);
            _context.SaveChanges();
        }

    }
}
