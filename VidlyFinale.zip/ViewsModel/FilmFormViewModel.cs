﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using $safeprojectname$.Models;

namespace $safeprojectname$.ViewsModel
{
    public class FilmFormViewModel
    {
        public List<Genere> Generi { get; set; }
        public Film Film { get; set; }
    }
}